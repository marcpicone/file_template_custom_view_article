#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}
#end
interface #parse("NameToCamelCase.kt")Contract {

    interface UserAction {

    }
    
    interface Screen {
 
    }
}