#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}
#end
class #parse("NameToCamelCase.kt")Presenter(
 private val screen : #parse("NameToCamelCase.kt")Contract.Screen
) : #parse("NameToCamelCase.kt")Contract.UserAction {

}