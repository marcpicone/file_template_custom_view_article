#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}
#end
import android.content.Context 
import android.util.AttributeSet 
import android.view.View 
import android.widget.FrameLayout 
import androidx.annotation.IdRes 
import ${PACKAGE_NAME}.R

class #parse("NameToCamelCase.kt")View @JvmOverloads constructor( 
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0 ) : FrameLayout(context, attrs, defStyleAttr){
 
    private val view = inflate(context, R.layout.${NAME}, this) 
}